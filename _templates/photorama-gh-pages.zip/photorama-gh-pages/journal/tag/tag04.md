---
layout: "journal_by_tag"
tag: "tag04"
permalink: "/journal/tag/tag04/"
---