---
layout: "journal_by_category"
category: "cat03"
permalink: "/journal/category/cat03/"
---